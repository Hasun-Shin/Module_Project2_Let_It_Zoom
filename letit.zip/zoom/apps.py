from django.apps import AppConfig


class ZoomConfig(AppConfig):
    name = 'zoom'
